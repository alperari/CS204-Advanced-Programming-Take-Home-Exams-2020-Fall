#include <iostream>
#include "Stack.h"
using namespace std;

//Constructor
template <class Type>
Stack<Type>::Stack()
{
	top=nullptr;
}

template <class Type>
StackNode<Type>* Stack<Type>::GetTopPointer(Stack<Type> myStack)
{
	return myStack.top;
}

//Push back elements to the stack
template <class Type>
void Stack<Type>::push(TreeNode<Type>* elmt)
{
	StackNode<Type> *newNode;

	newNode = new StackNode<Type>;
	newNode->value = elmt;

	if(isEmpty())
	{
		top = newNode;
		newNode->next = nullptr;
	}
	else
	{
		newNode->next = top;
		top = newNode;
	}
}
//Pop up elements from the stack
template <class Type>
TreeNode<Type>* Stack<Type>::pop()
{
	StackNode<Type> *temp;

	if(!isEmpty())
	{
		TreeNode<Type>* elmt = top->value;
		temp = top->next;
		delete top;
		top = temp;
		return elmt;
	}
	return nullptr;
}


//If the stack is empty check function
template <class Type>
bool Stack<Type>::isEmpty()
{
	return (top==nullptr);
}
