#ifndef _BINARYTREE_H
#define _BINARYTREE_H

#include <iostream>
#include "Stack.h"
#include "Stack.cpp"

using namespace std;

template <class Type>
class BinaryTree
{
 public:
  //Constructor
  BinaryTree();
  //Copy Constructor
  BinaryTree(const BinaryTree<Type>&);
  //Destructor
  ~BinaryTree();
  
  // Insertion method
  void insert(Type);
  TreeNode<Type>* getRoot();
  
  //operators
  const BinaryTree<Type>& operator= (const BinaryTree<Type>& rhs);
  bool operator== (const BinaryTree<Type>& rhs);
  bool operator!= (const BinaryTree<Type>& rhs);
  void operator+= (const BinaryTree<Type>& rhs);
  BinaryTree<Type> operator+ (const BinaryTree<Type>& rhs);
  void operator+= (Type number);
  BinaryTree<Type> operator+(Type number);
  
  template <class Type>
  friend BinaryTree<Type> operator+(Type number, const BinaryTree<Type>&);

  template <class Type>
  friend ostream& operator<<(ostream&, const BinaryTree<Type>&);

 private:
  //The root of the tree
  TreeNode<Type>* root;

  template<class Type>
  friend class Iterator;
};

template <class Type>
class Iterator{
 public:
  //Constructor
  Iterator();

  void Init(const BinaryTree<Type>& );
  bool hasNext();
  TreeNode<Type>* Next(); //Actually the same with InOrderNext()
  TreeNode<Type>* InOrderNext(); 
  TreeNode<Type>* PreOrderNext(); 
  
 private:
  TreeNode<Type>* myCurrent;
  Stack<Type>* stack;
  Stack<Type>* stack2;
};

#endif
