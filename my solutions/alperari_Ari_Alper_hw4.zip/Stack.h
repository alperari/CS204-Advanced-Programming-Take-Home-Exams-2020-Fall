#ifndef _STACK_H
#define _STACK_H

#include <iostream>

template <class Type>
struct TreeNode
{
  Type value;
  TreeNode *left;
  TreeNode *right;

  TreeNode(){
    left = nullptr;
    right = nullptr;
  }
};

template <class Type>
struct StackNode
{
  TreeNode<Type>* value;
  StackNode *next;
};


template <class Type>
class Stack
{
private:
  StackNode<Type> *top;
  StackNode<Type>* GetTopPointer(Stack<Type> myStack);
  
public:
  Stack(void);
  void push(TreeNode<Type>* );
  TreeNode<Type>* pop();
  bool isEmpty();
};

#endif
