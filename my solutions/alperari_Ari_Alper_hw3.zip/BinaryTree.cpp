#include "BinaryTree.h"
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

//Constructor
BinaryTree::BinaryTree(){
  root = nullptr;
}

//Copy Constructor
BinaryTree::BinaryTree(const BinaryTree& rhs){
  //TODO: Implement deep copy constructor
  //You may make use of Iterator class
    root = rhs.generateCopy();
}

//DestructorHelper
void BinaryTree::DestructTree(TreeNode* nodePtr)
{
    if (nodePtr == nullptr)
    {
        return;
    }
    DestructTree(nodePtr->left);
    DestructTree(nodePtr->right);
    //cout << "deleted " << nodePtr->value << endl;
    delete nodePtr;
        
    
}
//Destructor
BinaryTree::~BinaryTree(){
  //TODO: Implement destructor
    DestructTree(root);
}

void BinaryTree::insert(int num) {
  //TODO: Implement insert function for BinaryTree
    TreeNode* NewNode = new TreeNode(num);
    if (!root)
    {
        root = NewNode;
    }
    else
    {
        TreeNode* cursor = root;
        while (cursor)
        {
            if (num < cursor->value)
            {
                if (cursor->left)
                {
                    cursor = cursor->left;
                }
                else
                {
                    cursor->left = NewNode;
                    break;
                }
            }
            else if (num > cursor->value)
            {
                if (cursor->right)
                {
                    cursor = cursor->right;
                }
                else
                {
                    cursor->right = NewNode;
                    break;
                }
            }
            else
            {
                cout << "Duplicate value found in tree." << endl;
                break;
            }
        }
    }

    
}

TreeNode* BinaryTree::generateCopy() const
{
    if (!root)
    {
        return nullptr;
    }
    else
    {
        TreeNode* newHead = nullptr;
        Iterator treeItr;
        treeItr.Init(*this);

        int value;
        bool flag = true;

        while (treeItr.hasNext())
        {
            value = treeItr.Next()->value;
            TreeNode* NewNode = new TreeNode(value);

            if (!newHead)
            {
                newHead = NewNode;
            }
            else
            {
                TreeNode* cursor = newHead;
                while (cursor && flag)
                {
                    if (value < cursor->value)
                    {
                        if (cursor->left)
                        {
                            cursor = cursor->left;
                        }
                        else
                        {
                            cursor->left = NewNode;
                            flag = false;
                        }
                    }
                    else if (value > cursor->value)
                    {
                        if (cursor->right)
                        {
                            cursor = cursor->right;
                        }
                        else
                        {
                            cursor->right = NewNode;
                            flag = false;
                        }
                    }
                }
                flag = true;
            }
            
        }
        return newHead;
    }
}
TreeNode* BinaryTree::getRoot() const
{
    return root;
}
void BinaryTree::deleteTree()
{
    DestructTree(root);
}

//***********************  Operators ************************************************************************
//Give the implementations of operators in here either as free function or member function
void coutHelper(TreeNode* nodeptr, ostream &os)
{
    if (nodeptr)
    {
        coutHelper(nodeptr->left, os);
        os << nodeptr->value << " ";
        coutHelper(nodeptr->right, os);
    }
}
ostream& operator << (ostream& os, const BinaryTree& rhs)
{
    coutHelper(rhs.root, os);
    return os;
}
const BinaryTree& BinaryTree::operator = (const BinaryTree& rhs)
{
    deleteTree();
    root = rhs.generateCopy();
    return *this;
}
const BinaryTree operator + (const BinaryTree& lhs,int num)
{
    BinaryTree result;
    result = lhs;
    result.insert(num);
    return result;
}
const BinaryTree& BinaryTree::operator += (const BinaryTree& rhs)
{
    Iterator itr;
    itr.Init(rhs);
    int value;
    while (itr.hasNext())
    {
        value = itr.Next()->value;
        this->insert(value);
    }
    return *this;

}
const BinaryTree operator + (int left_integer, const BinaryTree& rhs)
{
    BinaryTree result;
    result.insert(left_integer);
    result += rhs;
    return result;
}
const BinaryTree& BinaryTree::operator += (int left_integer)
{
    this->insert(left_integer);
    return *this;
}
const BinaryTree operator + (const BinaryTree& lhs, const BinaryTree& rhs)
{
    BinaryTree result;
    Iterator itr1, itr2;
    itr1.Init(lhs);
    while (itr1.hasNext())
    {
        result.insert(itr1.Next()->value);
    }
    itr2.Init(rhs);
    while (itr2.hasNext())
    {
        result.insert(itr2.Next()->value);
    }
    return result;
}
bool BinaryTree::operator == (const BinaryTree& rhs)
{
    vector<int> vec1;
    vector<int> vec2;
    Iterator itr1, itr2;
    int value;
    itr1.Init(*this);
    while (itr1.hasNext())
    {
        value = itr1.Next()->value;
        vec1.push_back(value);
    }
    itr2.Init(rhs);
    while (itr2.hasNext())
    {
        value = itr2.Next()->value;
        vec2.push_back(value);
    }
    sort(vec1.begin(), vec1.end());
    sort(vec2.begin(), vec2.end());
    if (vec1 == vec2)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool BinaryTree::operator != (const BinaryTree& rhs)
{
    return !(*this == rhs);
}
/*
 *  ITERATOR CLASS
*/

//Constructor
Iterator::Iterator()
  :myCurrent(nullptr), stack(nullptr)
{}

void Iterator::FillStack(TreeNode* current)
{
    while (current)
    {
        stack->push(current);
        current = current->left;
    }
}

void Iterator::Init(const BinaryTree &tree)
{
  myCurrent = tree.root;
  stack = new Stack();
  FillStack(myCurrent);
}

//Returns true if tree has more nodes to explore
bool Iterator::hasNext()
{
  //TODO: Implement a function to see if there is more nodes to iterate over.
    return !stack->isEmpty();
}

//Next node to explore

TreeNode* Iterator::Next()
{
    TreeNode* node = nullptr;
  //TODO: Implement next function of the iterator
  //Note that it returns the next element
    node = stack->pop();
    FillStack(node->right);
    return node;
}

TreeNode* Iterator::getCurrent()
{
    return myCurrent;
}



