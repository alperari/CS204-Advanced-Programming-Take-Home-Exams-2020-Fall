#ifndef _BINARYTREE_H
#define _BINARYTREE_H

#include <iostream>
#include "Stack.h"

using namespace std;

class BinaryTree
{
 public:
  //Constructor
  BinaryTree();
  //Copy Constructor - TODO in .cpp file
  BinaryTree(const BinaryTree&);

  //Destructor helper
  void DestructTree(TreeNode*);
  //Destructor
  ~BinaryTree();
  
  // Insertion method
  void insert(int);
  TreeNode* generateCopy() const ;
  TreeNode* getRoot() const;
  void deleteTree();

  // ************Operators*************
  const BinaryTree& operator = (const BinaryTree& rhs);
  const BinaryTree& operator += (const BinaryTree& rhs);
  const  BinaryTree& operator += (int left_integer);
  bool operator == (const BinaryTree& rhs);
  bool operator != (const BinaryTree& rhs);


  const friend BinaryTree operator + (const BinaryTree& lhs, const BinaryTree& rhs);   // t1+t2
  const friend BinaryTree operator + (const BinaryTree& lhs,int num);     //t1+5
  const friend  BinaryTree operator + (int left_integer, const BinaryTree & rhs);   //5+t1
  friend ostream& operator << (ostream& os, const BinaryTree& rhs);
  
private:
  //The root of the tree
  TreeNode* root;

  friend class Iterator;
};

class Iterator{
public:
  //Constructor
  Iterator();
  
  void Init(const BinaryTree& );
  void FillStack(TreeNode*);
  bool hasNext();
  TreeNode* Next();
  TreeNode* getCurrent();
  
private:
  TreeNode* myCurrent;
  Stack* stack;
};

#endif
