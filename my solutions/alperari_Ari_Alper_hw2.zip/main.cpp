// ALPER ARI 27017

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include "strutils.h"

using namespace std;

struct metroStopNode
{
	string metroStopName;
	metroStopNode* left;
	metroStopNode* right;

	int costBetweenNext;

	vector<metroStopNode*> transfers;

	metroStopNode(const string name, int cost=0): 
		metroStopName (name),
		left(nullptr), 
		right(nullptr), 
		costBetweenNext(cost){}
	
};
struct metroLineNode
{
	string metroLineName;
	metroLineNode* next = nullptr;
	metroStopNode* metroStops_head = nullptr;

};

metroLineNode* head = nullptr;  //assign this pointer
								//to the beginning of
								//metro lines later

void DetermineTransfers();

void AddStopNodeFromFile(metroLineNode* LineNode, string& stopname)
{
	metroStopNode* StopNode = new metroStopNode(stopname);

	if (LineNode->metroStops_head == nullptr)  // if there is no metrostop assigned before, headx= null
	{
		LineNode->metroStops_head = StopNode;
	}
	else
	{
		metroStopNode* cursor = LineNode->metroStops_head;  //this will go through list

		while (cursor->right != nullptr)
		{
			cursor = cursor->right;
		}
		//now the cursor is at rightmostStopNode->metroStopName = stopname;

		cursor->right = StopNode;
		StopNode->left = cursor;

	}

}


void printOnlyLine(metroLineNode* line);

bool search_Line(const string& linename);
bool search_Stop(const string& stopname);


void _addNodeBeginning(const string& linename, const string& stopname, const string& cost1);
void _addNodeToMiddle(const string& linename, const string prev_stopname, const string& stopname, const string& cost1, const string& cost2);
void addMetroStop();


void _deleteNode(const string& linename, const string& stopname);
void deleteMetroStop();

void printMainMenu();
bool consistencyCheck();
void processMainMenu();
void pathFinder(metroStopNode* ,const string&);



void printMetroLinesDetailed();


int main()
{
	fstream file;
	// first open metroline file 
	string filename ;
	cout << "Enter the name of the metro line data file:" << endl;
	cin >> filename;
	file.open(filename.c_str());
	if (file.fail()) {cout << "Failed to open file." << endl;return 1;}
	string line;

	string LineName, StopName;
	while (getline(file, line))
	{
		istringstream mystream(line);
		getline(mystream, LineName, ',');   //LineName is assigned to our variable, determinor is ","
		
		//Create new metroLine Node
		metroLineNode* LineNode = new metroLineNode;
		LineNode->metroLineName = LineName;
		LineNode->next = nullptr;
	
		while (getline(mystream, StopName, ','))  //continue assigning names to metrostopname, using MetroLine's pointer
		{
			if (StopName.find("#") != string::npos)
			{
				StopName = StopName.substr(0U, StopName.length() - 1);
			}
			AddStopNodeFromFile(LineNode,StopName);
		}
		if (head == nullptr)
		{
			head = LineNode;			// add new LineNode to head if head does not point to smwhr
		}
		else
		{
			metroLineNode* cursor = head;
			while (cursor->next != nullptr)
			{
				cursor = cursor->next;
			}
			cursor->next = LineNode;

		}
	}
	file.close();
	
	//until so far, our 2d structure is complete,
	//then open costs file
	//we will add costs between stops and finalize our list
	cout << "Enter the name of costs file:" << endl;
	cin >> filename;
	file.open(filename.c_str());
	if (file.fail()) { cout << "Failed to open file." << endl;return 1; }

	string cost;

	metroLineNode* cursorLine = head;
	while (getline(file, line))
	{
		istringstream mystream(line);
		getline(mystream, LineName, ',');

		metroStopNode* cursorStop = cursorLine->metroStops_head;

		if(LineName == cursorLine->metroLineName)
		{
			while (getline(mystream, cost, ','))
			{
				cursorStop->costBetweenNext = atoi(cost);
				cursorStop = cursorStop->right;
			}
		}
		cursorLine = cursorLine->next;
	}

	file.close();
	cout << endl;

	int hops;
	//cout << "Enter maximum number of hops:" << endl;
	//cin >> hops;

	DetermineTransfers();

	processMainMenu();
	

	return 0;
}

void printMainMenu()
{
	cout << endl;
	cout << "I***********************************************I" << endl
		<< "I               0 - EXIT PROGRAM                I" << endl
		<< "I               1 - PRINT LINES                 I" << endl
		<< "I               2 - ADD METRO STOP              I" << endl
		<< "I               3 - DELETE METRO STOP           I" << endl
		<< "I               4 - PATH FINDER                 I" << endl
		<< "I***********************************************I" << endl
		<< ">>";
	cout << endl;
}

bool consistencyCheck()
{
	metroLineNode* currBL = head;
	metroStopNode* currBS = nullptr;
	metroStopNode* currRight = nullptr;
	while (currBL)
	{
		currBS = currBL->metroStops_head;
		while (currBS)
		{
			currRight = currBS->right;
			if (currRight != nullptr && currRight->left != currBS)
			{
				cout << "Inconsistency for " << currBL->metroLineName << " " << currBS->metroStopName << endl;
				return false;
			}

			currBS = currBS->right;
		}
		currBL = currBL->next;
	}
	return true;
}

void processMainMenu()
{
	string start, target;
	metroStopNode* currentposition = nullptr;

	metroLineNode* cursorLine = head;
	metroStopNode* cursorStop = nullptr;
	bool flag = false;

	char input;
	do
	{
		if(!consistencyCheck())
		{
			cout << "There are inconsistencies. Exit." << endl;
			return;
		}
		printMainMenu();
		cout << "Please enter your option" << endl;
		cin >> input;
		switch (input)
		{
		case '0':
			cout << "Thanks for using our software" << endl;
			return;
		case '1':
			printMetroLinesDetailed();
			break;
		case '2':
			addMetroStop();
			break;
		case '3':
			deleteMetroStop();
			break;
		case '4':
			cout << "Where are you now?" << endl; cin >> start;
			cout << "Where do you want to go?" << endl; cin >> target;
			//check if currentstop exists in the list
			if (!search_Stop(start) || !search_Stop(target))
			{
				cout << "Metro stop does not exist in the table. Going back to previous menu." << endl;
				return;
			}
			flag = false;
			cursorLine = head;

			while (cursorLine && !flag)
			{
				cursorStop = cursorLine->metroStops_head;
				while (cursorStop && !flag)
				{
					if (cursorStop->metroStopName == start)
					{
						currentposition = cursorStop;
						flag = true;
					}

					cursorStop = cursorStop->right;
				}
				cursorLine = cursorLine->next;
			}
			//we took the adress of our current Stop, now go into pathfinder

			//pathFinder(currentposition, target);

			break;

		default:
			cout << "Invalid option: please enter again" << endl;
		}

	} while (true);
}

void printMetroLinesDetailed()
{
	metroLineNode* cursorLine = head;
	metroStopNode* cursorStop = nullptr;
	while (cursorLine!= nullptr)
	{
		cout << cursorLine->metroLineName << ": ";

		cursorStop = cursorLine->metroStops_head;
		while (cursorStop != nullptr)
		{
			if (cursorStop->right != nullptr)
				cout << cursorStop->metroStopName << " <-" << cursorStop->costBetweenNext << "-> " ;
			else
				cout << cursorStop->metroStopName.substr(0U, cursorStop->metroStopName.length());
			cursorStop = cursorStop->right;
		}
		cout << endl;
		cursorLine = cursorLine->next;
	}
	
}

void printOnlyLine(metroLineNode* line)
{
	metroStopNode* cursor = line->metroStops_head;
	cout << line->metroLineName << ": ";

	while (cursor)
	{
		if (cursor->right != nullptr)
		{
			cout << cursor->metroStopName << " <-" << cursor->costBetweenNext << "-> ";
			
		}
		else
		{
			cout << cursor->metroStopName.substr(0U, cursor->metroStopName.length()) << endl;
		}
		cursor = cursor->right;
	}
}
bool search_Line(const string& linename)
{
	metroLineNode* cursorLine = head;
	while (cursorLine)
	{
		if(cursorLine->metroLineName == linename)
		{
			//print line info here
			cout << "The metro line information is shown below" << endl;
			printOnlyLine(cursorLine);
			return true;
		}
		cursorLine = cursorLine->next;
	}
	return false;
}
bool search_Stop(const string& stopname)
{
	metroLineNode* cursorLine = head;
	metroStopNode* cursorStop = nullptr;
	while (cursorLine)
	{
		cursorStop = cursorLine->metroStops_head;
		while (cursorStop)
		{
			if (cursorStop->metroStopName == stopname)
			{
				return true;
			}
			cursorStop = cursorStop->right;
		}
		cursorLine = cursorLine->next;
	}
	return false;
}

void _addNodeBeginning(const string& linename, const string& stopname, const string&cost1)
{
	metroStopNode* StopNode = new metroStopNode(stopname, atoi(cost1));			//create new node

	metroLineNode* cursorLine = head;
	while (cursorLine)
	{
		if (cursorLine->metroLineName == linename)
		{
			//create a new stop node and add it to the head
			metroStopNode* next = cursorLine->metroStops_head;
			StopNode->right = next;
			cursorLine->metroStops_head = StopNode;
			next->left = StopNode;
			printOnlyLine(cursorLine);
			return;
		}
		cursorLine = cursorLine->next;
	}
}
void _addNodeToMiddle(const string& linename, const string prev_stopname, const string& stopname, const string& cost1, const string& cost2)
{
	metroStopNode* StopNode = new metroStopNode(stopname, atoi(cost2));		//this time it will have cost2 instead of cost1

	metroLineNode* cursorLine = head;
	metroStopNode* cursorStop = nullptr;
	metroStopNode* next = nullptr;
	while (cursorLine)
	{
		if (cursorLine->metroLineName == linename)
		{
			cursorStop = cursorLine->metroStops_head;
			while (cursorStop)
			{
				if (cursorStop->metroStopName == prev_stopname)   //we have found our node in the middle of list
				{
					if (cursorStop->right != nullptr)				//we are in the middle
					{
						next = cursorStop->right;

						cursorStop->right = StopNode;
						cursorStop->costBetweenNext = atoi(cost1);
						StopNode->right = next;
						StopNode->left = cursorStop;
						next->left = StopNode;
						printOnlyLine(cursorLine);
						return;
					}
					else										//we are at the end of the line
					{
						cursorStop->right = StopNode;
						cursorStop->costBetweenNext = atoi(cost1);
						StopNode->left = cursorStop;
						printOnlyLine(cursorLine);
						return;
					}
					
				}
				
			
				cursorStop = cursorStop->right;
			}
		}
		cursorLine = cursorLine->next;
	}
}
void addMetroStop()
{
	string linename,stopname,prev_stopname,cost1,cost2;
	cout << "Enter the name of the metro line to insert a new metro stop (0 for main menu)" << endl;
	cin >> linename;
	if (linename != "0")
	{
		if (!search_Line(linename))
		{
			cout << "Metro line cannot be found. Going back to previous menu." << endl;
			return;
		}
		else				//we found metro stop in our 
		{
			cout << "Enter the name of the new metro stop" << endl;
			cin >> stopname;
			if (search_Stop(stopname))	//stopname exists in list
			{
				cout << stopname <<" Metro stop already exists. Going back to previous menu." << endl;
				return;
			}
			else					//stopname does not exist in list, go on process
			{						//now add our stop:
				cout << "Enter the name of the previous metro stop for the new one(0 to put the new one as the first metro stop)" << endl;
				cin >> prev_stopname;
				cout << "Enter new cost 1" << endl; cin >> cost1;
				cout << "Enter new cost 2 " << endl; cin >> cost2;
				if (prev_stopname == "0")	
				{
					//add to the beginning
					_addNodeBeginning(linename, stopname, cost1);
				}
				else				 
				{
					//add to the correct place
					//but first search it in the line
					while (!search_Stop(prev_stopname))
					{
						cout << "Metro stop does not exist. Typo? Enter again (0 for main menu)" << endl;
						cin >> prev_stopname;

						if (prev_stopname == "0")
						{
							return;
						}
					}
					//now prev_stopname existing in the list
					//add to the correct place
					_addNodeToMiddle(linename,prev_stopname,stopname,cost1,cost2);
				}
			}
		}
	}
	else
	{
		//return to main menu
		return;
	}
}

void _deleteNode(const string& linename, const string& stopname)
{
	metroLineNode* cursorLine = head;
	metroLineNode* templine =  nullptr;

	metroStopNode* cursorStop = nullptr;
	metroStopNode* tempstop = nullptr;
	metroStopNode* prev = nullptr;
	while (cursorLine)
	{
		cursorStop = cursorLine->metroStops_head;
		if (cursorLine->metroLineName == linename)
		{
			while (cursorStop)
			{
				if (cursorStop->metroStopName == stopname)
				{
					if (cursorStop->left == nullptr && cursorStop->right != nullptr)		//toDelete node is at the beginning
					{
						tempstop = cursorStop->right;
						cursorLine->metroStops_head = tempstop;
						tempstop->left = nullptr;
						delete cursorStop;
						printOnlyLine(cursorLine);
						return;
					}
					else if (cursorStop->right == nullptr && cursorStop->left != nullptr)    //toDelete is at the end        					{
					{
						tempstop = cursorStop->left;
						tempstop->right = nullptr;
						delete cursorStop;
						printOnlyLine(cursorLine);
						return;
					}
					else if(cursorStop->right != nullptr && cursorStop->left != nullptr)				//toDelete node is in the middle
					{
						prev = cursorStop->left;
						tempstop = cursorStop->right;
						prev->right = tempstop;
						tempstop->left = prev;

						prev->costBetweenNext += cursorStop->costBetweenNext;
						delete cursorStop;
						printOnlyLine(cursorLine);
						return;
					}
					else if (cursorStop->right == nullptr && cursorStop->left == nullptr)		//this means we have only one node in line
					{
						//now delete Stop Node and Line Node at the same time
						templine = head;
						tempstop = cursorStop;
						delete tempstop;
						while (templine->next != cursorLine)
						{
							templine = templine->next;
						}
						templine->next = cursorLine->next;
						delete cursorLine;
						return;
					}
				}
				cursorStop = cursorStop->right;
			}
		}
		cursorLine = cursorLine->next;
	}
}
void deleteMetroStop()
{
	string linename, stopname;
	cout << "Enter the name of the metro line to delete a new metro stop (0 for main menu)" << endl;
	cin >> linename;
	if (linename == "0")
	{
		return;
	}
	else
	{
		if (!search_Line(linename))
		{
			cout << "Metro line cannot be found. Going back to previous menu." << endl;
			return;
		}
		else
		{
			//our line is found
			cout << "Enter the name of the metro stop to delete (0 for main menu)" << endl;
			cin >> stopname;
			if (stopname == "0")
			{
				return;
			}
			while (!search_Stop(stopname))
			{
				cout << "Metro stop cannot be found. Enter the name of the metro stop to delete (0 for main menu)" << endl;
				cin >> stopname;
				if (stopname == "0")
				{
					return;
				}
			}
			//now our stop name is found
			_deleteNode(linename,stopname);
		}
	}
	
}


static bool s = false;
int direction = 1;
void pathFinder(metroStopNode* currentposition, const string& targetname)
{
	
	if (currentposition->metroStopName == targetname)
	{
		//we have found our target
		cout << endl << endl << "FOUND IT " << endl;
		s = true;
		return;
	}
	if (!currentposition)
	{
		return;
	}
	else
	{
		for (int i = 0; i < currentposition->transfers.size(); i++)
		{
			currentposition = currentposition->transfers[i];
			pathFinder(currentposition->right, targetname);
			cout << currentposition->metroStopName << " - ";
		}
		

			
		
		
	}
	
}


void DetermineTransfers()
{
	metroLineNode* cursorLine = head;
	metroLineNode* cursorLine2 = head;
	metroStopNode* cursorStop, *cursorStop2 = nullptr;
	while (cursorLine)
	{
		cursorStop = cursorLine->metroStops_head;
		while (cursorStop)
		{
					cursorLine2 = head;
					while (cursorLine2)
					{
						cursorStop2 = cursorLine2->metroStops_head;
						while (cursorStop2)
						{
							if (cursorStop->metroStopName == cursorStop2->metroStopName )
							{
								// we found next transfer, now add this stopNode to our stopNode1->vector
								cursorStop->transfers.push_back(cursorStop2);

							}


							cursorStop2 = cursorStop2->right;
						}

						cursorLine2 = cursorLine2->next;
					}


			cursorStop = cursorStop->right;
		}

		cursorLine = cursorLine->next;
	}


}